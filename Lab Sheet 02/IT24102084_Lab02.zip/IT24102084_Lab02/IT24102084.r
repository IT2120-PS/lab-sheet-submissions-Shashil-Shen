x <- c(1,2,3)
x[1] / x[2]^3 - 1 + 2 * x[3] - x[2-1]

sum((1:15) %% 3 == 0)

val <- c(1,7,3.5)

find_max_index <- function(val){
  max_value <- val[1]
  max_index <- 1
  
  for(i in 1:length(val)){
    if(val[i] > max_value){
      max_value <- val[i]
      max_index <- i
    }
  }
  return(max_index)
}

print(find_max_index(val))

print(which.max(val))

getwd()